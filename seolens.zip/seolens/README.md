# SEOLens — Chrome Extension
**Autor: Lukáš Kameniczki**

Kompletný SEO audit priamo v prehliadači. Žiadne prepínanie nástrojov.

---

## Štruktúra projektu

```
seolens/
├── manifest.json          # Chrome Extension v3 konfigurácia
├── popup.html             # UI popup (400px)
├── src/
│   ├── content.js         # Scraper — injektuje sa do každej stránky
│   ├── popup.js           # Logika popupu, render, export PDF
│   └── background.js      # Service worker
└── icons/
    ├── icon16.png
    ├── icon32.png
    ├── icon48.png
    └── icon128.png        ← treba doplniť vlastné ikony
```

---

## Inštalácia (developer mode)

1. Otvor Chrome → `chrome://extensions/`
2. Zapni **Developer mode** (vpravo hore)
3. Klikni **Load unpacked**
4. Vyber celý priečinok `seolens/`
5. Ikona sa objaví v toolbare

---

## Čo extension robí

### Tab 1 — SEO Audit
- ✅ Meta title & description (s počtom znakov a varovaním)
- ✅ Canonical URL (prítomnosť / chýba)
- ✅ Štruktúra nadpisov H1–H6 (stromový pohľad)
- ✅ Schema.org / JSON-LD detekcia (typy + čo chýba)
- ✅ Obrázky bez alt textu
- ✅ Open Graph náhľad (og:title, og:image, og:description)
- ✅ HTTPS, hreflang, robots meta, jazyk stránky
- ✅ Počet interných / externých linkov
- ✅ Celkové SEO skóre (0–100)

### Tab 2 — Kľúčové slová
- ✅ Top 30 kľúčových slov z textu stránky
- ✅ Hustota (%) s progress barom
- ✅ Počet výskytov
- ✅ Filtrovanie cez vyhľadávacie pole
- ✅ Celkový počet slov na stránke

### Tab 3 — Export PDF
- ✅ White-label report (meno klienta + dátum)
- ✅ Výber sekcií (toggles)
- ✅ Generuje HTML → otvorí print dialóg (PDF/A)
- ✅ Obsahuje: audit, kľúčové slová, odporúčania s prioritami

---

## Ikony

Ikony treba doplniť manuálne do `icons/`. Odporúčané:
- Veľkosti: 16×16, 32×32, 48×48, 128×128 px
- Formát: PNG s transparentným pozadím
- Nástroj: [favicon.io](https://favicon.io) alebo Figma

---

## Ďalší rozvoj (roadmap)

- [ ] Integrácia Google Search Console API (reálne pozície)
- [ ] Porovnanie s predchádzajúcim auditom (diff)
- [ ] Core Web Vitals cez CrUX API
- [ ] Kontrola broken links (fetch HEAD requests)
- [ ] Flesch čitateľnosť textu
- [ ] Dark mode
- [ ] Export do Google Docs

---

*SEOLens · Lukáš Kameniczki*
