// SEOLens — popup.js

// ─── Tab switching ────────────────────────────────────────────────────────────

document.querySelectorAll(".tab-btn").forEach(function(btn) {
  btn.addEventListener("click", function() {
    document.querySelectorAll(".tab-btn").forEach(function(b) { b.classList.remove("active"); });
    document.querySelectorAll(".tab-panel").forEach(function(p) { p.classList.remove("active"); });
    btn.classList.add("active");
    document.getElementById("tab-" + btn.dataset.tab).classList.add("active");
  });
});

document.querySelectorAll(".toggle-row").forEach(function(row) {
  row.addEventListener("click", function() {
    var id = row.dataset.toggle;
    if (!id) return;
    var t = document.getElementById("toggle-" + id);
    if (!t) return;
    t.classList.toggle("on");
    t.classList.toggle("off");
  });
});

// ─── Helpers ─────────────────────────────────────────────────────────────────

function el(id) { return document.getElementById(id); }

function calcScore(data) {
  var score = 100;
  if (!data.meta.title || data.meta.titleStatus !== "ok")       score -= 10;
  if (!data.meta.description || data.meta.descStatus !== "ok") score -= 10;
  if (!data.meta.canonical)                                     score -= 10;
  if (data.headings.filter(function(h) { return h.level === 1; }).length !== 1) score -= 10;
  if (data.schema.items.length === 0)                           score -= 10;
  if (data.images.noAltCount > 0) score -= Math.min(10, data.images.noAltCount * 2);
  if (!data.misc.isHttps)                                       score -= 15;
  if (!data.og.image)                                           score -= 5;
  if (data.misc.isThinContent)                                  score -= 5;
  if (data.cwvStatus && data.cwvStatus.lcp === "err")  score -= 5;
  if (data.cwvStatus && data.cwvStatus.cls === "err")  score -= 5;
  return Math.max(0, score);
}

function scoreColor(s) {
  return s >= 80 ? "#22c55e" : s >= 50 ? "#f59e0b" : "#ef4444";
}

function cwvColor(st) {
  var map = { ok: "#22c55e", warn: "#f59e0b", err: "#ef4444", unknown: "#999" };
  return map[st] || "#999";
}

function cwvFmt(key, val) {
  if (val === null || val === undefined) return null;
  return key === "cls" ? val.toFixed(3) : val + "ms";
}

function charBadge(len, status) {
  var cls = status === "ok" ? "char-ok" : status === "short" ? "char-warn" : status === "long" ? "char-warn" : "char-err";
  return '<span class="char-count ' + cls + '">' + len + ' zn.</span>';
}

function div(cls, inner) {
  return '<div class="' + cls + '">' + inner + '</div>';
}

function auditRow(iconCls, iconTxt, labelHtml, valueHtml, hintHtml) {
  return '<div class="audit-row">' +
    '<div class="audit-icon ' + iconCls + '">' + iconTxt + '</div>' +
    '<div class="audit-content">' +
      '<div class="audit-label">' + labelHtml + '</div>' +
      '<div class="audit-value audit-value--wrap">' + valueHtml + '</div>' +
      (hintHtml ? '<div class="audit-hint">' + hintHtml + '</div>' : '') +
    '</div>' +
  '</div>';
}

// ─── Schema validation ────────────────────────────────────────────────────────

function validateSchema(type, raw) {
  var errors = [], warnings = [];
  function has(key) { return raw[key] !== undefined && raw[key] !== null && raw[key] !== ""; }

  var rules = {
    Organization:         { req: ["name","url"],                       rec: ["logo","contactPoint","address","telephone","email","sameAs"] },
    LocalBusiness:        { req: ["name","address","telephone"],        rec: ["openingHours","geo","image","priceRange"] },
    WebSite:              { req: ["name","url"],                        rec: ["potentialAction","description"] },
    WebPage:              { req: ["name","url"],                        rec: ["description","breadcrumb","datePublished","dateModified"] },
    Product:              { req: ["name","offers"],                     rec: ["image","description","brand","sku","aggregateRating"] },
    Article:              { req: ["headline","author","datePublished"],  rec: ["image","dateModified","publisher","description"] },
    BlogPosting:          { req: ["headline","author","datePublished"],  rec: ["image","dateModified","publisher"] },
    FAQPage:              { req: ["mainEntity"],                        rec: [] },
    BreadcrumbList:       { req: ["itemListElement"],                   rec: [] },
    Person:               { req: ["name"],                              rec: ["url","image","jobTitle","email"] },
    Event:                { req: ["name","startDate","location"],        rec: ["endDate","description","image","organizer"] },
    Review:               { req: ["reviewRating","author"],             rec: ["reviewBody","itemReviewed"] },
    SiteNavigationElement:{ req: ["name","url"],                        rec: [] },
    ImageObject:          { req: ["url"],                               rec: ["name","description","contentUrl"] },
  };

  var rule = rules[type];
  if (!rule) { warnings.push('Typ "' + type + '" — vlastné pravidlá nie sú definované'); return { errors: errors, warnings: warnings }; }

  rule.req.forEach(function(k) { if (!has(k)) errors.push("Chýba povinná vlastnosť: " + k); });
  rule.rec.forEach(function(k) { if (!has(k)) warnings.push("Odporúčaná vlastnosť chýba: " + k); });

  if (type === "Product" && raw.offers) {
    var offer = Array.isArray(raw.offers) ? raw.offers[0] : raw.offers;
    if (offer && !offer.price && !offer.priceRange) warnings.push("offers: chýba cena (price/priceRange)");
    if (offer && !offer.availability)   warnings.push("offers: chýba availability");
    if (offer && !offer.priceCurrency)  warnings.push("offers: chýba priceCurrency");
  }
  if ((type === "Organization" || type === "LocalBusiness") && raw.address && typeof raw.address === "object") {
    if (!raw.address.addressLocality) warnings.push("address: chýba addressLocality");
    if (!raw.address.addressCountry)  warnings.push("address: chýba addressCountry");
  }
  return { errors: errors, warnings: warnings };
}

// ─── Render: Audit ────────────────────────────────────────────────────────────

function renderAudit(data) {
  var score = calcScore(data);
  var color = scoreColor(score);
  var deg   = (score / 100) * 360;

  el("score-circle").style.background = "conic-gradient(" + color + " 0deg " + deg + "deg, #1e1e1e " + deg + "deg 360deg)";
  el("score-num").textContent = score;
  el("score-num").style.color = color;

  try {
    var u = new URL(data.url);
    el("current-url").textContent = u.hostname + u.pathname.slice(0, 22);
  } catch(_) {
    el("current-url").textContent = data.url.slice(0, 30);
  }

  var warns = 0, errs = 0;

  // ── Meta
  var metaHtml = "";

  var tSt = data.meta.titleStatus;
  if (tSt !== "ok") warns++;
  var tHint = tSt === "long" ? "⚠ Príliš dlhý (max 60 znakov)" : tSt === "short" ? "⚠ Príliš krátky (min 30 znakov)" : "";
  metaHtml += auditRow(
    tSt === "ok" ? "icon-ok" : "icon-warn",
    tSt === "ok" ? "✓" : "⚠",
    "Meta Title " + charBadge(data.meta.titleLength, tSt),
    data.meta.title || "— chýba",
    tHint
  );

  var dSt = data.meta.descStatus;
  if (dSt !== "ok") warns++;
  var dHint = dSt === "long" ? "⚠ Príliš dlhý (max 160 znakov)" : dSt === "short" ? "⚠ Príliš krátky (min 120 znakov)" : "";
  metaHtml += auditRow(
    dSt === "ok" ? "icon-ok" : "icon-warn",
    dSt === "ok" ? "✓" : "⚠",
    "Meta Description " + charBadge(data.meta.descLength, dSt),
    data.meta.description || "— chýba",
    dHint
  );

  var hasCanon = !!data.meta.canonical;
  if (!hasCanon) errs++;
  metaHtml += auditRow(
    hasCanon ? "icon-ok" : "icon-err",
    hasCanon ? "✓" : "✕",
    "Canonical URL",
    data.meta.canonical || "— nie je definovaný",
    !hasCanon ? '<span style="color:#ef4444">✕ Riziko duplicitného obsahu</span>' : ""
  );

  var ratio   = data.textHtmlRatio || 0;
  var ratioSt = ratio >= 15 ? "ok" : ratio >= 5 ? "warn" : "err";
  if (ratioSt !== "ok") warns++;
  var ratioCls = ratioSt === "ok" ? "char-ok" : ratioSt === "warn" ? "char-warn" : "char-err";
  var ratioHint = ratioSt === "err" ? '<span style="color:#ef4444">✕ Príliš málo textu voči HTML kódu</span>' : ratioSt === "warn" ? "⚠ Nízky pomer — pridajte viac textu" : "";
  metaHtml += auditRow(
    "icon-" + ratioSt,
    ratioSt === "ok" ? "✓" : ratioSt === "warn" ? "⚠" : "✕",
    'Text / HTML pomer <span class="char-count ' + ratioCls + '">' + ratio + '%</span>',
    "Odporúčané: 15–70% | Text: " + data.keywords.totalWords + " slov",
    ratioHint
  );

  if (data.misc.isThinContent) {
    warns++;
    metaHtml += auditRow("icon-warn", "⚠", "Thin content", data.keywords.totalWords + " slov (min. 300)", "⚠ Málo obsahu môže znižovať ranking");
  }

  el("meta-section").innerHTML = metaHtml;

  // ── Headings
  var h1s = data.headings.filter(function(h) { return h.level === 1; });
  if (h1s.length !== 1) warns++;

  var hHtml = '<div class="heading-tree">';
  var mlMap = [0,0,12,22,32,40,46];
  data.headings.slice(0, 12).forEach(function(h) {
    var ml = mlMap[h.level] || 0;
    hHtml += '<div class="h-item" style="margin-left:' + ml + 'px">' +
      '<span class="h-tag h' + Math.min(h.level,4) + '-tag">H' + h.level + '</span>' +
      '<span class="h-text">' + h.text + '</span>' +
    '</div>';
  });
  if (data.headings.length > 12) hHtml += '<div class="audit-hint" style="padding:4px 0">+' + (data.headings.length - 12) + ' ďalších…</div>';
  hHtml += '</div>';
  if (h1s.length === 0) { errs++;  hHtml += '<div class="audit-hint" style="color:#ef4444;padding:4px 0">✕ Žiadny H1 na stránke!</div>'; }
  if (h1s.length > 1)   { warns++; hHtml += '<div class="audit-hint" style="padding:4px 0">⚠ Viac ako jeden H1 (' + h1s.length + '×)</div>'; }
  el("headings-section").innerHTML = hHtml;

  // ── Schema
  renderSchema(data.schema, function(w, e) { warns += w; errs += e; });

  // ── CWV — show run button
  el("cwv-section").innerHTML =
    '<div class="cwv-idle">' +
      '<div class="cwv-idle-icon">' +
        '<svg width="18" height="18" viewBox="0 0 18 18" fill="none"><circle cx="9" cy="9" r="7" stroke="#22c55e" stroke-width="1.5"/><path d="M6 9l2 2 4-4" stroke="#22c55e" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
      '</div>' +
      '<div class="cwv-idle-title">Core Web Vitals</div>' +
      '<div class="cwv-idle-text">Meranie vyžaduje načítanie stránky.<br>Stránka sa obnoví a zmeria výkon.</div>' +
      '<button class="cwv-run-btn" id="cwv-run-btn">' +
        '<svg width="11" height="11" viewBox="0 0 11 11" fill="none"><polygon points="1,1 10,5.5 1,10" fill="currentColor"/></svg>' +
        'Spustiť CWV test' +
      '</button>' +
      '<div class="cwv-run-sub">Performance Observer API · reálne hodnoty</div>' +
    '</div>';

  el("cwv-run-btn").addEventListener("click", function() { runCWVTest(); });

  // ── Images
  var noAltCount = data.images.noAltCount || 0;
  var noAltList  = data.images.noAltList  || [];
  if (noAltCount > 0) warns++;

  var imgHtml = auditRow(
    noAltCount === 0 ? "icon-ok" : "icon-warn",
    noAltCount === 0 ? "✓" : "⚠",
    "Obrázky celkom: " + data.images.total,
    noAltCount > 0 ? noAltCount + " bez alt textu · " + (data.images.total - noAltCount) + " OK" : "Všetky majú alt text ✓",
    ""
  );

  if (noAltList.length > 0) {
    imgHtml += '<div class="accordion"><button class="accordion-btn" data-acc="images">Zobraziť obrázky bez alt textu (' + noAltList.length + ') <span class="acc-arrow">▾</span></button>' +
      '<div class="accordion-body" id="acc-body-images">';
    noAltList.forEach(function(img) {
      imgHtml += '<div class="img-item">' +
        '<div class="img-thumb-wrap">' + (img.src ? '<img class="img-thumb" src="' + img.src + '" alt="" onerror="this.style.display=\'none\'">' : '') + '</div>' +
        '<div class="img-info"><div class="img-src">' + (img.src.split("/").pop().slice(0,40) || img.src.slice(0,40)) + '</div>' +
        '<div class="img-size">' + (img.width && img.height ? img.width + "×" + img.height + "px" : "—") + '</div></div>' +
      '</div>';
    });
    imgHtml += '</div></div>';
  }
  el("images-section").innerHTML = imgHtml;
  setupAccordions();

  // ── Broken links
  el("links-section").innerHTML =
    '<div class="links-loading"><span class="spinner"></span> Kontrolujem linky (' + Math.min(data.links.list.length, 30) + ')…</div>';
  checkBrokenLinks(data.links.list);

  // ── Tech files
  checkTechFiles(data.url);

  // ── OG
  var ogImg = data.og.image
    ? '<img src="' + data.og.image + '" style="width:100%;height:100%;object-fit:cover" onerror="this.parentElement.innerHTML=\'og:image · nenačítalo sa\'">'
    : "og:image · chýba";
  if (!data.og.image) warns++;
  el("og-section").innerHTML =
    '<div class="og-card">' +
      '<div class="og-img">' + ogImg + '</div>' +
      '<div class="og-meta">' +
        '<div class="og-site">' + (data.og.siteName || "") + '</div>' +
        '<div class="og-title">' + (data.og.title || data.meta.title || "—") + '</div>' +
        '<div class="og-desc">'  + (data.og.description || data.meta.description || "—") + '</div>' +
      '</div>' +
    '</div>';

  // ── Misc
  el("misc-section").innerHTML =
    '<div class="extra-grid">' +
      makeExtraItem(data.misc.isHttps ? "#f0fdf4" : "#fee2e2",
        '<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><rect x="2" y="5" width="10" height="7" rx="1.5" stroke="' + (data.misc.isHttps ? "#22c55e" : "#ef4444") + '" stroke-width="1.4"/><path d="M5 5V4a2 2 0 014 0v1" stroke="' + (data.misc.isHttps ? "#22c55e" : "#ef4444") + '" stroke-width="1.4"/></svg>',
        "HTTPS", data.misc.isHttps ? "zabezpečený" : "nezabezpečený") +
      makeExtraItem("#eff6ff",
        '<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M2 7h10M7 2v10" stroke="#3b82f6" stroke-width="1.4" stroke-linecap="round"/></svg>',
        "Linky", data.links.internal + " int · " + data.links.external + " ext") +
      makeExtraItem("#fdf4ff",
        '<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M4 10l2-6 2 4 1.5-2.5L11 10" stroke="#a855f7" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
        "Slov na stránke", data.keywords.totalWords.toLocaleString()) +
      makeExtraItem("#fff7ed",
        '<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><rect x="1.5" y="3" width="11" height="8" rx="1.5" stroke="#f97316" stroke-width="1.4"/><path d="M5 3V2M9 3V2" stroke="#f97316" stroke-width="1.4" stroke-linecap="round"/></svg>',
        "Hreflang", data.hreflang.length > 0 ? data.hreflang.map(function(h){ return h.lang; }).join(", ") : "—") +
      makeExtraItem("#f0fdf4",
        '<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 2C4.24 2 2 4.24 2 7s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5z" stroke="#22c55e" stroke-width="1.4"/><path d="M7 5v3l2 1" stroke="#22c55e" stroke-width="1.4" stroke-linecap="round"/></svg>',
        "Robots", data.meta.robots || "—") +
      makeExtraItem("#f5f3ff",
        '<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><rect x="2" y="2" width="10" height="10" rx="2" stroke="#7c3aed" stroke-width="1.4"/><path d="M5 7h4M5 5h4M5 9h2" stroke="#7c3aed" stroke-width="1.4" stroke-linecap="round"/></svg>',
        "Jazyk", data.meta.lang || "—") +
    '</div>';

  el("warn-badge").textContent    = warns + " warn";
  el("error-badge").textContent   = errs  + " chýb";
  el("warn-badge").style.display  = warns > 0 ? "inline" : "none";
  el("error-badge").style.display = errs  > 0 ? "inline" : "none";
}

function makeExtraItem(bg, iconSvg, name, sub) {
  return '<div class="extra-item">' +
    '<div class="extra-icon" style="background:' + bg + '">' + iconSvg + '</div>' +
    '<div class="extra-text"><div class="extra-name">' + name + '</div><div class="extra-sub">' + sub + '</div></div>' +
  '</div>';
}

// ─── Schema render (separate function, no nested template literals) ───────────

function renderSchema(schema, countCb) {
  if (schema.items.length === 0) {
    countCb(1, 0);
    el("schema-section").innerHTML =
      auditRow("icon-warn", "⚠", "Schema.org", "Žiadne štruktúrované dáta nenájdené", "⚠ Doplňte JSON-LD (Organization, WebSite, Product...)");
    return;
  }

  // Group by type
  var typeMap = {};
  schema.items.forEach(function(s) {
    if (!typeMap[s.type]) typeMap[s.type] = [];
    typeMap[s.type].push(s);
  });
  var uniqueTypes = Object.keys(typeMap);
  var hasMicrodata = schema.items.some(function(s) { return s.source === "microdata"; });

  // Build chips
  var chipsHtml = '<div class="schema-chips" id="schema-chips">';
  uniqueTypes.forEach(function(type, idx) {
    var items      = typeMap[type];
    var val        = validateSchema(type, items[0].raw);
    var hasErr     = val.errors.length > 0;
    var hasWarn    = val.warnings.length > 0;
    var chipCls    = hasErr ? "chip-err" : hasWarn ? "chip-warn" : "chip-ok";
    var icon       = hasErr ? "✕" : hasWarn ? "⚠" : "✓";
    var countBadge = items.length > 1 ? ' <span class="schema-count">' + items.length + "×</span>" : "";
    chipsHtml += '<span class="schema-chip ' + chipCls + ' schema-chip-btn" data-schema-idx="' + idx + '" style="cursor:pointer">' +
      icon + " " + type + countBadge +
    '</span>';
  });
  chipsHtml += '</div>';
  chipsHtml += '<div style="font-size:10px;color:#aaa;font-family:monospace;padding:4px 0 8px">' +
    schema.items.length + ' typov · ' + (hasMicrodata ? "JSON-LD + Microdata" : "JSON-LD") + ' · klikni na typ pre detail' +
  '</div>';
  chipsHtml += '<div class="schema-detail" id="schema-detail" style="display:none"></div>';

  el("schema-section").innerHTML = chipsHtml;

  // Click handlers
  el("schema-section").querySelectorAll(".schema-chip-btn").forEach(function(chip) {
    chip.addEventListener("click", function() {
      var idx    = parseInt(chip.dataset.schemaIdx);
      var type   = uniqueTypes[idx];
      var items  = typeMap[type];
      var detail = el("schema-detail");
      var isOpen = detail.style.display !== "none" && detail.dataset.open === String(idx);

      el("schema-section").querySelectorAll(".schema-chip-btn").forEach(function(c) { c.classList.remove("chip-active"); });

      if (isOpen) {
        detail.style.display = "none";
        detail.dataset.open  = "";
        return;
      }

      chip.classList.add("chip-active");

      var val    = validateSchema(type, items[0].raw);
      var raw    = items[0].raw;
      var dHtml  = '<div class="schema-drawer">';
      dHtml += '<div class="schema-drawer-title">' + type +
        (items.length > 1 ? ' <span style="font-size:10px;color:#aaa;font-weight:400">' + items.length + '× instancií</span>' : '') +
      '</div>';

      if (val.errors.length) {
        val.errors.forEach(function(e) { dHtml += '<div class="sv-item sv-err">✕ ' + e + '</div>'; });
      }
      if (val.warnings.length) {
        val.warnings.forEach(function(w) { dHtml += '<div class="sv-item sv-warn">⚠ ' + w + '</div>'; });
      }
      if (!val.errors.length && !val.warnings.length) {
        dHtml += '<div class="sv-item sv-ok">✓ Schema je validná, všetky odporúčané vlastnosti sú prítomné</div>';
      }

      // Show key props
      var showProps = ["name","url","description","image","telephone","email","datePublished","price","@id"];
      var propsHtml = "";
      showProps.forEach(function(p) {
        if (raw[p] === undefined || raw[p] === null) return;
        var val2 = typeof raw[p] === "object" ? JSON.stringify(raw[p]).slice(0, 60) + "…" : String(raw[p]).slice(0, 80);
        propsHtml += '<div class="schema-prop"><span class="sp-key">' + p + '</span><span class="sp-val">' + val2 + '</span></div>';
      });
      if (propsHtml) dHtml += '<div class="schema-props">' + propsHtml + '</div>';

      dHtml += '</div>';
      detail.innerHTML    = dHtml;
      detail.style.display = "block";
      detail.dataset.open  = String(idx);
    });
  });
}

// ─── CWV ─────────────────────────────────────────────────────────────────────

var CWV_METRICS = [
  { key: "lcp",  label: "LCP",  full: "Largest Contentful Paint", threshold: "≤2.5s",  max: 4000 },
  { key: "fcp",  label: "FCP",  full: "First Contentful Paint",   threshold: "≤1.8s",  max: 3000 },
  { key: "ttfb", label: "TTFB", full: "Time to First Byte",        threshold: "≤800ms", max: 1800 },
  { key: "cls",  label: "CLS",  full: "Cumulative Layout Shift",   threshold: "≤0.1",   max: 0.25 },
  { key: "fid",  label: "FID",  full: "First Input Delay",         threshold: "≤100ms", max: 300  },
];

function renderCWVResults(cwv, cwvSt) {
  var html = '<div class="cwv-rows">';
  CWV_METRICS.forEach(function(m) {
    var val     = cwv[m.key];
    var st      = (cwvSt && cwvSt[m.key]) || "unknown";
    var color   = cwvColor(st);
    var fmtVal  = cwvFmt(m.key, val);
    var barPct  = val === null || val === undefined ? 0 : Math.min(100, (val / m.max) * 100);
    html += '<div class="cwv-row">' +
      '<div class="cwv-left">' +
        '<div class="cwv-dot" style="background:' + color + '"></div>' +
        '<div class="cwv-labels">' +
          '<span class="cwv-label-main">' + m.label + '</span>' +
          '<span class="cwv-label-full">'  + m.full  + '</span>' +
        '</div>' +
      '</div>' +
      '<div class="cwv-right">' +
        '<div class="cwv-bar-track"><div class="cwv-bar-fill" style="width:' + barPct + '%;background:' + color + '"></div></div>' +
        '<div class="cwv-val-wrap">' +
          '<span class="cwv-value" style="color:' + color + '">' + (fmtVal || "—") + '</span>' +
          '<span class="cwv-threshold">' + m.threshold + '</span>' +
        '</div>' +
      '</div>' +
    '</div>';
  });
  html += '</div>';
  html += '<div class="cwv-note" style="display:flex;align-items:center;justify-content:space-between">' +
    '<span>Performance Observer API · reálne hodnoty</span>' +
    '<button class="cwv-rerun-btn" id="cwv-rerun-btn">↻ Merať znova</button>' +
  '</div>';

  el("cwv-section").innerHTML = html;
  var rerunBtn = el("cwv-rerun-btn");
  if (rerunBtn) rerunBtn.addEventListener("click", function() { runCWVTest(); });
}

async function runCWVTest() {
  el("cwv-section").innerHTML =
    '<div class="cwv-loading">' +
      '<div class="cwv-spinner-wrap">' +
        '<span class="spinner" style="width:16px;height:16px;border-width:2.5px"></span>' +
        '<span class="cwv-loading-text">Načítavam stránku a meriam…</span>' +
      '</div>' +
      '<div style="font-size:10px;color:#bbb;font-family:monospace">Stránka sa obnoví na pozadí</div>' +
    '</div>';

  try {
    var tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    var tab  = tabs[0];

    await chrome.tabs.reload(tab.id, { bypassCache: true });

    await new Promise(function(resolve) {
      chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
        if (tabId === tab.id && info.status === "complete") {
          chrome.tabs.onUpdated.removeListener(listener);
          setTimeout(resolve, 700);
        }
      });
    });

    var results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["src/content.js"] });
    var fresh   = results && results[0] && results[0].result;
    if (!fresh) throw new Error("Nepodarilo sa získať dáta");

    renderCWVResults(fresh.cwv, fresh.cwvStatus);
  } catch(err) {
    el("cwv-section").innerHTML =
      '<div class="cwv-idle">' +
        '<div class="cwv-idle-icon" style="background:#fef2f2">' +
          '<svg width="18" height="18" viewBox="0 0 18 18" fill="none"><circle cx="9" cy="9" r="7" stroke="#ef4444" stroke-width="1.5"/><path d="M9 6v3M9 12h.01" stroke="#ef4444" stroke-width="1.5" stroke-linecap="round"/></svg>' +
        '</div>' +
        '<div class="cwv-idle-title" style="color:#dc2626">Chyba merania</div>' +
        '<div class="cwv-idle-text">' + err.message + '</div>' +
        '<button class="cwv-run-btn" id="cwv-run-btn2">Skúsiť znova</button>' +
      '</div>';
    var btn2 = el("cwv-run-btn2");
    if (btn2) btn2.addEventListener("click", function() { runCWVTest(); });
  }
}

// ─── Accordion ────────────────────────────────────────────────────────────────

function setupAccordions() {
  document.querySelectorAll(".accordion-btn").forEach(function(btn) {
    btn.addEventListener("click", function() {
      var id   = btn.dataset.acc;
      var body = document.getElementById("acc-body-" + id);
      var arr  = btn.querySelector(".acc-arrow");
      var open = body.classList.contains("open");
      body.classList.toggle("open", !open);
      if (arr) arr.textContent = open ? "▾" : "▴";
    });
  });
}

// ─── Broken links ─────────────────────────────────────────────────────────────

async function checkBrokenLinks(linkList) {
  var urls = [];
  var seen = {};
  linkList.forEach(function(l) {
    if (l.href.startsWith("http") && !seen[l.href]) { seen[l.href] = true; urls.push(l.href); }
  });
  urls = urls.slice(0, 30);

  if (!urls.length) {
    el("links-section").innerHTML = '<div class="audit-hint" style="padding:6px 0">Žiadne HTTP linky na kontrolu.</div>';
    return;
  }

  try {
    var res     = await chrome.runtime.sendMessage({ type: "CHECK_LINKS", urls: urls });
    var results = (res && res.results) || [];
    var broken  = results.filter(function(r) { return r.type === "broken"; });
    var redirs  = results.filter(function(r) { return r.type === "redirect"; });
    var errs2   = results.filter(function(r) { return r.type === "error" || r.type === "timeout"; });
    var ok      = results.filter(function(r) { return r.type === "ok"; });

    var html = '<div class="link-summary">' +
      '<span class="ls-badge ls-ok">✓ ' + ok.length + ' OK</span>' +
      (redirs.length  ? '<span class="ls-badge ls-redir">↗ ' + redirs.length + ' redirect</span>' : '') +
      (broken.length  ? '<span class="ls-badge ls-broken">✕ ' + broken.length + ' broken</span>'  : '') +
      (errs2.length   ? '<span class="ls-badge ls-err">? ' + errs2.length + ' chyba</span>'        : '') +
    '</div>';

    var bad = broken.concat(redirs).concat(errs2);
    if (!bad.length) {
      html += '<div class="audit-hint" style="color:#22c55e;padding:4px 0">Všetky skontrolované linky sú funkčné.</div>';
    } else {
      html += '<div class="link-list">';
      bad.slice(0, 12).forEach(function(r) {
        var cls  = r.type === "broken" ? "ls-broken" : r.type === "redirect" ? "ls-redir" : "ls-err";
        var code = r.type === "broken" ? r.status : r.type === "redirect" ? r.status : "ERR";
        var path = r.url.replace(/^https?:\/\/[^/]+/, "").slice(0, 36) || "/";
        html += '<div class="link-item"><span class="link-status ' + cls + '">' + code + '</span><span class="link-url" title="' + r.url + '">' + path + '</span></div>';
      });
      html += '</div>';
    }
    el("links-section").innerHTML = html;
  } catch(_) {
    el("links-section").innerHTML = '<div class="audit-hint" style="color:#aaa;padding:4px 0">Kontrola linkov nie je dostupná.</div>';
  }
}

// ─── Keywords ─────────────────────────────────────────────────────────────────

function renderKeywords(data) {
  el("kw-total").textContent = data.keywords.top.length;
  el("kw-words").textContent = data.keywords.totalWords.toLocaleString();

  var html = "";
  data.keywords.top.forEach(function(kw, i) {
    var bw = Math.min(100, (kw.density / 5) * 100);
    var bc = kw.density > 4 ? "#f59e0b" : "#22c55e";
    html +=
      '<div class="kw-row" style="animation-delay:' + (i * 0.03) + 's">' +
        '<div class="kw-rank">' + (i+1) + '</div>' +
        '<div class="kw-word">' + kw.word + '</div>' +
        '<div class="kw-density-wrap">' +
          '<div class="kw-bar-bg"><div class="kw-bar-fill" style="width:' + bw + '%;background:' + bc + '"></div></div>' +
          '<div class="kw-pct">' + kw.density + '%</div>' +
        '</div>' +
        '<div class="kw-count">' + kw.count + '×</div>' +
      '</div>';
  });
  el("kw-list").innerHTML = html;

  el("kw-search-input").addEventListener("input", function(e) {
    var q = e.target.value.toLowerCase();
    document.querySelectorAll(".kw-row").forEach(function(row) {
      row.style.display = row.querySelector(".kw-word").textContent.toLowerCase().includes(q) ? "" : "none";
    });
  });
}

// ─── Export ───────────────────────────────────────────────────────────────────

function setupExport(data) {
  el("export-btn").addEventListener("click", async function() {
    var clientName = el("client-name").value || "Klient";
    var reportDate = el("report-date").value  || new Date().toLocaleDateString("sk-SK");

    // Save report data to session storage, then open the extension's report page
    await chrome.storage.session.set({
      seolens_report: { data: data, clientName: clientName, reportDate: reportDate }
    });
    chrome.tabs.create({ url: chrome.runtime.getURL("report.html") });
  });
}

// ─── Boot ─────────────────────────────────────────────────────────────────────

async function init() {
  var tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  var tab  = tabs[0];
  try {
    var results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["src/content.js"] });
    var data = results && results[0] && results[0].result;
    if (!data) { el("loading").textContent = "Nepodarilo sa načítať dáta stránky."; return; }
    el("loading").style.display = "none";
    el("app").style.display     = "block";
    renderAudit(data);
    renderKeywords(data);
    setupExport(data);
    el("report-date").value = new Date().toLocaleDateString("sk-SK");
  } catch(err) {
    el("loading").textContent = "Chyba: " + err.message;
  }
}

document.addEventListener("DOMContentLoaded", init);

// ─── Tech files (robots.txt, sitemap.xml, llms.txt) ──────────────────────────

async function checkTechFiles(pageUrl) {
  var section = el("tech-section");
  section.innerHTML =
    '<div class="links-loading"><span class="spinner"></span> Kontrolujem technické súbory…</div>';

  var origin;
  try { origin = new URL(pageUrl).origin; } catch(_) { return; }

  var res;
  try {
    res = await chrome.runtime.sendMessage({ type: "CHECK_TECH_FILES", origin: origin });
  } catch(_) {
    section.innerHTML = '<div class="audit-hint" style="color:#aaa;padding:6px 0">Kontrola nie je dostupná.</div>';
    return;
  }

  var r = res && res.results;
  if (!r) return;

  var order = ["robots","sitemap","sitemapIndex","llms","llmsFull","security"];
  var html  = '<div class="tech-list">';

  order.forEach(function(key) {
    var f = r[key];
    if (!f) return;
    if (!f.required && !f.ok) return;

    var isOk     = f.ok;
    var dotColor = isOk ? "#22c55e" : f.required ? "#f59e0b" : "#d1d5db";
    var cardCls  = isOk ? "st-ok" : f.required ? "st-warn" : "st-miss";
    var badgeText = isOk ? (f.status + " OK") : "404 chýba";
    var badgeCls  = isOk ? "tb-ok" : "tb-miss";

    // Sub info — one liner
    var sub = "";
    if (isOk) {
      if (key === "robots")                     sub = (f.extra.lineCount||0) + " riadkov";
      if (key === "sitemap")                    sub = f.extra.isIndex ? "Index · " + (f.extra.urlCount||0) + " sitemáp" : (f.extra.urlCount||0) + " URL";
      if (key === "sitemapIndex")               sub = (f.extra.urlCount||0) + " sitemáp";
      if (key === "llms" || key === "llmsFull") sub = (f.extra.sizeKb||0) + " kB";
      if (key === "security")                   sub = "nájdený";
    }

    // Clickable only if file exists — opens in new tab
    var clickAttr = isOk
      ? 'style="cursor:pointer" data-url="' + f.url + '"'
      : '';

    html += '<div class="tech-card ' + cardCls + '" ' + clickAttr + '>';
    html +=   '<div class="tech-top">' +
                '<div class="tech-dot" style="background:' + dotColor + '"></div>' +
                '<div class="tech-name">' + f.label +
                  (sub ? ' <span style="font-weight:400;color:#aaa;font-size:10px">' + sub + '</span>' : '') +
                '</div>' +
                '<span class="tech-badge ' + badgeCls + '">' + badgeText + '</span>' +
                (isOk ? '<span style="font-size:10px;color:#ccc;margin-left:4px">↗</span>' : '') +
              '</div>';

    if (!isOk && f.required) {
      var hints = {
        robots:  "Odporúčame pridať robots.txt",
        sitemap: "Odporúčame pridať sitemap.xml",
      };
      if (hints[key]) html += '<div class="tech-hint">⚠ ' + hints[key] + '</div>';
    }

    html += '</div>';
  });

  // Optional missing
  var optMiss = ["llms","llmsFull","security"].filter(function(k) { return r[k] && !r[k].ok; });
  if (optMiss.length) {
    html += '<div class="tech-optional-miss">Nenájdené (voliteľné): ' +
      optMiss.map(function(k){ return r[k].label; }).join(" · ") + '</div>';
  }

  html += '</div>';
  section.innerHTML = html;

  // Click → open in new tab
  section.querySelectorAll(".tech-card[data-url]").forEach(function(card) {
    card.addEventListener("click", function() {
      chrome.tabs.create({ url: card.dataset.url });
    });
  });
}

function techDr(key, val, valCls) {
  return '<div class="tech-dr"><span class="td-k">' + key + '</span><span class="td-v' + (valCls ? " "+valCls : "") + '">' + val + '</span></div>';
}
