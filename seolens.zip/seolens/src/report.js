// SEOLens — report.js
// Runs inside report.html (an extension page — no CSP issues with local scripts)

(function() {

// ── helpers shared with popup ──
function cwvFmt(key, val) {
  if (val === null || val === undefined) return null;
  if (key === "cls") return val.toFixed(3);
  return val >= 1000 ? (val / 1000).toFixed(2) + "s" : Math.round(val) + "ms";
}
function scoreColor(s) { return s >= 80 ? "#22c55e" : s >= 60 ? "#f59e0b" : "#ef4444"; }
function calcScore(data) {
  var score = 100;
  if (!data.meta.title)                          score -= 15;
  else if (data.meta.titleStatus !== "ok")       score -= 5;
  if (!data.meta.description)                    score -= 10;
  else if (data.meta.descStatus  !== "ok")       score -= 3;
  if (!data.meta.canonical)                      score -= 10;
  if (data.schema.items.length === 0)            score -= 10;
  if (data.images.noAltCount > 0)               score -= 5;
  if (!data.misc.isHttps)                        score -= 15;
  var h1s = (data.headings||[]).filter(function(h){ return h.level===1; });
  if (h1s.length === 0)                          score -= 10;
  else if (h1s.length > 1)                       score -= 5;
  if (!data.og.title && !data.og.description)    score -= 5;
  var ratio = data.textHtmlRatio || 0;
  if (ratio < 5) score -= 10;
  else if (ratio < 15) score -= 4;
  if (data.misc.isThinContent) score -= 10;
  return Math.max(0, Math.min(100, score));
}

function pct(st) { return st==="ok"?"#dcfce7":st==="warn"?"#fef3c7":st==="err"?"#fee2e2":"#f5f5f5"; }
function ptxt(st){ return st==="ok"?"#15803d":st==="warn"?"#b45309":st==="err"?"#dc2626":"#aaa"; }

function statusBadge(st) {
  if (!st || st==="unknown") return "<span style='color:#aaa;font-family:monospace'>—</span>";
  return "<span style='background:"+pct(st)+";color:"+ptxt(st)+";padding:2px 9px;border-radius:10px;font-size:10px;font-weight:700;font-family:monospace'>"+st.toUpperCase()+"</span>";
}

// ── Main render ──
async function init() {
  var stored = await chrome.storage.session.get("seolens_report");
  var report = stored && stored.seolens_report;
  if (!report) {
    document.getElementById("loading").textContent = "Žiadne dáta reportu. Otvor report znova cez SEOLens.";
    return;
  }

  var data       = report.data;
  var clientName = report.clientName || "Klient";
  var reportDate = report.reportDate || new Date().toLocaleDateString("sk-SK");
  var cwv        = data.cwv       || {};
  var cwvSt      = data.cwvStatus || {};

  document.title = "SEO Report — " + clientName;

  var score  = calcScore(data);
  var scolor = scoreColor(score);
  var url    = new URL(data.url);

  // toolbar
  document.getElementById("tb-meta").textContent = clientName + " · " + url.hostname + " · " + reportDate;
  document.getElementById("toolbar").style.display = "flex";
  document.getElementById("loading").style.display = "none";

  // ── Schema types
  var schemaTypes = [];
  var seen = {};
  (data.schema.items||[]).forEach(function(s){ if(!seen[s.type]){seen[s.type]=true;schemaTypes.push(s.type);} });
  var schemaHtml = schemaTypes.length
    ? schemaTypes.map(function(t){ return "<span class='chip'>✓ "+t+"</span>"; }).join(" ")
    : "<span style='color:#aaa'>Žiadne schema.org dáta</span>";

  // ── CWV rows
  var CWV_METRICS = [
    { key:"lcp",  label:"LCP — Largest Contentful Paint", hint:"≤ 2 500ms" },
    { key:"fcp",  label:"FCP — First Contentful Paint",   hint:"≤ 1 800ms" },
    { key:"ttfb", label:"TTFB — Time to First Byte",       hint:"≤ 800ms"  },
    { key:"cls",  label:"CLS — Cumulative Layout Shift",   hint:"≤ 0.1"    },
    { key:"fid",  label:"FID — First Input Delay",         hint:"≤ 100ms"  },
  ];
  var cwvRows = CWV_METRICS.map(function(m) {
    var val=cwv[m.key], st=cwvSt[m.key]||"unknown", fv=cwvFmt(m.key,val)||"—";
    return "<tr><td>"+m.label+"</td><td style='font-family:monospace;font-weight:700;color:"+ptxt(st)+"'>"+fv+"</td><td style='color:#bbb;font-size:11px;font-family:monospace'>"+m.hint+"</td><td style='text-align:right'>"+statusBadge(st)+"</td></tr>";
  }).join("");

  // ── Headings
  var hRows = (data.headings||[]).slice(0,10).map(function(h) {
    var ml=(h.level-1)*14;
    var bg=h.level===1?"#1a1a1a":h.level===2?"#4b5563":"#9ca3af";
    return "<tr><td style='padding-left:"+(10+ml)+"px;width:"+(24+ml)+"px'><span style='background:"+bg+";color:#fff;font-size:9px;font-weight:700;padding:1px 5px;border-radius:3px;font-family:monospace'>H"+h.level+"</span></td><td style='color:#444'>"+escHtml(h.text)+"</td></tr>";
  }).join("");

  // ── Keywords
  var topKws = (data.keywords.top||[]).slice(0,12);
  var kwRows = topKws.map(function(k,i) {
    var bar=Math.min(100,Math.round(k.density/5*100));
    var bc=k.density>4?"#f59e0b":"#22c55e";
    return "<tr><td style='color:#ccc;width:24px;font-family:monospace'>"+(i+1)+"</td>"
      +"<td style='font-weight:600'>"+escHtml(k.word)+"</td>"
      +"<td><div style='background:#f0f0f0;border-radius:2px;height:5px;width:80px'><div style='background:"+bc+";height:5px;width:"+bar+"%;border-radius:2px'></div></div></td>"
      +"<td style='color:"+bc+";font-family:monospace;font-weight:600'>"+k.density+"%</td>"
      +"<td style='color:#aaa;text-align:right;font-family:monospace'>"+k.count+"×</td></tr>";
  }).join("");

  // ── Recommendations
  var recos = [];
  if (!data.meta.canonical)          recos.push({p:"VYSOKÁ",c:"#dc2626",bc:"#fee2e2",t:"Doplniť canonical URL",d:"Hrozí penalizácia za duplicitný obsah."});
  if (data.meta.titleStatus!=="ok")  recos.push({p:"VYSOKÁ",c:"#dc2626",bc:"#fee2e2",t:"Opraviť meta title",d:data.meta.titleLength+" znakov — odporúčané 30–60."});
  if (data.meta.descStatus!=="ok")   recos.push({p:"STREDNÁ",c:"#d97706",bc:"#fef3c7",t:"Opraviť meta description",d:data.meta.descLength+" znakov — odporúčané 120–160."});
  if (data.schema.items.length===0)  recos.push({p:"STREDNÁ",c:"#d97706",bc:"#fef3c7",t:"Implementovať Schema.org",d:"Doplňte JSON-LD štruktúrované dáta."});
  if (data.images.noAltCount>0)      recos.push({p:"STREDNÁ",c:"#d97706",bc:"#fef3c7",t:"Doplniť alt texty ("+data.images.noAltCount+"×)",d:"Alt texty zlepšujú prístupnosť aj indexáciu."});
  if (!data.misc.isHttps)            recos.push({p:"VYSOKÁ",c:"#dc2626",bc:"#fee2e2",t:"Nasadiť HTTPS",d:"Google penalizuje nezabezpečené stránky."});
  if (!data.og.image)                recos.push({p:"NÍZKA",c:"#15803d",bc:"#dcfce7",t:"Doplniť og:image",d:"Chýba Open Graph obrázok pre sociálne siete."});
  recos.push({p:"NÍZKA",c:"#15803d",bc:"#dcfce7",t:"Google Search Console",d:"Sledujte indexáciu, CTR a pozície kľúčových slov."});
  var recoRows = recos.map(function(r) {
    return "<tr><td style='width:80px'><span style='background:"+r.bc+";color:"+r.c+";font-size:9px;font-weight:700;padding:2px 7px;border-radius:3px;font-family:monospace;white-space:nowrap'>"+r.p+"</span></td><td style='font-weight:600;padding-right:12px'>"+escHtml(r.t)+"</td><td style='color:#666;font-size:11px'>"+r.d+"</td></tr>";
  }).join("");

  // ── Build HTML
  var reportEl = document.getElementById("report");
  reportEl.innerHTML = [

    // PAGE 1 — Cover
    "<div class='page'>",
      "<div class='cover-logo'>SEO<span>Lens</span></div>",
      "<div class='cover-stripe'></div>",
      "<div class='cover-eyebrow'>SEO Audit Report</div>",
      "<div class='cover-title'>"+(clientName!=="Klient"?escHtml(clientName):url.hostname)+"</div>",
      "<div class='cover-url'>"+url.href+"</div>",
      "<div class='cover-score'>",
        "<div class='score-num' style='color:"+scolor+"'>"+score+"</div>",
        "<div>",
          "<div class='score-lbl'>SEO Skóre</div>",
          "<div class='score-sub'>z 100 bodov<br>Dátum: "+reportDate+"<br>SEOLens audit</div>",
        "</div>",
      "</div>",
      "<table class='info-tbl'>",
        "<tr><td>URL</td><td>"+url.href+"</td></tr>",
        "<tr><td>Klient</td><td>"+escHtml(clientName)+"</td></tr>",
        "<tr><td>HTTPS</td><td>"+(data.misc.isHttps?"✓ Zabezpečený":"✕ Nezabezpečený")+"</td></tr>",
        "<tr><td>Jazyk stránky</td><td>"+(data.meta.lang||"—")+"</td></tr>",
        "<tr><td>Slov na stránke</td><td>"+data.keywords.totalWords.toLocaleString()+"</td></tr>",
        "<tr><td>Schema.org typov</td><td>"+schemaTypes.length+"</td></tr>",
        "<tr><td>Text / HTML pomer</td><td>"+data.textHtmlRatio+"%</td></tr>",
        "<tr><td>Interné linky</td><td>"+data.links.internal+"</td></tr>",
        "<tr><td>Externé linky</td><td>"+data.links.external+"</td></tr>",
      "</table>",
      "<div class='page-footer'><span>SEOLens · Lukáš Kameniczki</span><span>"+reportDate+"</span><span>1 / 3</span></div>",
    "</div>",

    // PAGE 2 — Meta + CWV
    "<div class='page'>",
      "<div class='sec-logo'>SEO<span>Lens</span></div>",
      "<h2>1. Meta tagy &amp; On-page</h2>",
      "<div class='meta-grid'>",
        "<div class='meta-box'><div class='meta-lbl'>Meta Title · "+data.meta.titleLength+" znakov</div><div class='meta-val'>"+(data.meta.title||"<span style='color:#ccc'>chýba</span>")+"</div></div>",
        "<div class='meta-box'><div class='meta-lbl'>Meta Description · "+data.meta.descLength+" znakov</div><div class='meta-val'>"+(data.meta.description||"<span style='color:#ccc'>chýba</span>")+"</div></div>",
        "<div class='meta-box'><div class='meta-lbl'>Canonical URL</div><div class='meta-val'>"+(data.meta.canonical||"<span style='color:#ccc'>chýba</span>")+"</div></div>",
        "<div class='meta-box'><div class='meta-lbl'>Text / HTML pomer</div><div class='meta-val'>"+data.textHtmlRatio+"%</div></div>",
      "</div>",
      "<h3>Štruktúra nadpisov</h3>",
      "<table class='dt'><tbody>"+hRows+"</tbody></table>",
      "<h3>Schema.org</h3>",
      "<div style='margin-top:6px;line-height:2.2'>"+schemaHtml+"</div>",
      "<h2 style='margin-top:28px'>2. Core Web Vitals</h2>",
      "<table class='dt'><thead><tr><th>Metrika</th><th>Hodnota</th><th>Threshold</th><th style='text-align:right'>Status</th></tr></thead><tbody>"+cwvRows+"</tbody></table>",
      "<div class='page-footer'><span>SEOLens · Lukáš Kameniczki</span><span>"+url.hostname+"</span><span>2 / 3</span></div>",
    "</div>",

    // PAGE 3 — Keywords + Recommendations
    "<div class='page'>",
      "<div class='sec-logo'>SEO<span>Lens</span></div>",
      "<h2>3. Kľúčové slová</h2>",
      "<p style='font-size:11px;color:#888;margin-bottom:12px'>Celkový počet slov: <strong style='color:#1a1a1a'>"+data.keywords.totalWords.toLocaleString()+"</strong></p>",
      "<table class='dt'><thead><tr><th>#</th><th>Slovo</th><th colspan='2'>Hustota</th><th style='text-align:right'>Výskyt</th></tr></thead><tbody>"+kwRows+"</tbody></table>",
      "<h2 style='margin-top:28px'>4. Odporúčania</h2>",
      "<table class='dt'><thead><tr><th>Priorita</th><th>Odporúčanie</th><th>Detail</th></tr></thead><tbody>"+recoRows+"</tbody></table>",
      "<div class='page-footer'><span>SEOLens · Lukáš Kameniczki</span><span>"+url.href+"</span><span>3 / 3</span></div>",
    "</div>",

  ].join("");

  reportEl.style.display = "block";

  // PDF button — window.print() with @media print CSS
  document.getElementById("pdf-btn").addEventListener("click", function() {
    window.print();
  });
}

function escHtml(s) {
  return String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}

init();

})();
