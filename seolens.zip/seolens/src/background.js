// SEOLens — background.js (Service Worker)
// Handles: tab communication, broken link checking

chrome.runtime.onInstalled.addListener(() => {
  console.log("SEOLens installed.");
});

// ─── Main message handler ─────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  // ── Get full SEO data from active tab
  if (message.type === "GET_SEO_DATA") {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      const tab = tabs[0];
      if (!tab?.id) { sendResponse({ error: "No active tab." }); return; }

      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ["src/content.js"],
        });
        sendResponse({ data: results?.[0]?.result || null });
      } catch (err) {
        sendResponse({ error: err.message });
      }
    });
    return true;
  }

  // ── Check broken links (HEAD requests, bypasses CORS)
  if (message.type === "CHECK_LINKS") {
    const urls = message.urls || [];
    checkLinks(urls).then(results => sendResponse({ results }));
    return true;
  }

});

// ─── Broken link checker ──────────────────────────────────────────────────────

async function checkLinks(urls) {
  const results = [];
  // Check max 30 links to keep it fast
  const toCheck = urls.slice(0, 30);

  const checks = toCheck.map(async (url) => {
    try {
      // Skip mailto:, tel:, javascript:, anchors
      if (!url.startsWith("http")) {
        return { url, status: "skip", type: "non-http" };
      }

      const controller = new AbortController();
      const timeout    = setTimeout(() => controller.abort(), 5000);

      const res = await fetch(url, {
        method:   "HEAD",
        signal:   controller.signal,
        redirect: "manual",   // catch redirects manually
      });

      clearTimeout(timeout);

      let type = "ok";
      if (res.status === 404 || res.status === 410) type = "broken";
      else if (res.status >= 300 && res.status < 400) type = "redirect";
      else if (res.status >= 500) type = "server-error";

      return { url, status: res.status, type };

    } catch (err) {
      if (err.name === "AbortError") return { url, status: "timeout", type: "timeout" };
      return { url, status: "error", type: "error", error: err.message };
    }
  });

  const settled = await Promise.allSettled(checks);
  settled.forEach(r => {
    if (r.status === "fulfilled") results.push(r.value);
  });

  return results;
}

// ─── Tech files checker (robots.txt, sitemap.xml, llms.txt) ──────────────────

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "CHECK_TECH_FILES") {
    checkTechFiles(message.origin).then(results => sendResponse({ results }));
    return true;
  }
});

async function checkTechFiles(origin) {
  const files = [
    {
      key:      "robots",
      url:      origin + "/robots.txt",
      label:    "robots.txt",
      required: true,
    },
    {
      key:      "sitemap",
      url:      origin + "/sitemap.xml",
      label:    "sitemap.xml",
      required: true,
    },
    {
      key:      "sitemapIndex",
      url:      origin + "/sitemap_index.xml",
      label:    "sitemap_index.xml",
      required: false,
    },
    {
      key:      "llms",
      url:      origin + "/llms.txt",
      label:    "llms.txt",
      required: false,
    },
    {
      key:      "llmsFull",
      url:      origin + "/llms-full.txt",
      label:    "llms-full.txt",
      required: false,
    },
    {
      key:      "security",
      url:      origin + "/.well-known/security.txt",
      label:    "security.txt",
      required: false,
    },
  ];

  const results = {};

  await Promise.all(files.map(async (f) => {
    try {
      const controller = new AbortController();
      const timeout    = setTimeout(() => controller.abort(), 6000);

      const res = await fetch(f.url, {
        method: "GET",
        signal: controller.signal,
      });
      clearTimeout(timeout);

      const contentType = res.headers.get("content-type") || "";
      let preview = null;
      let extra   = {};

      if (res.ok) {
        const text = await res.text();
        preview    = text.slice(0, 500);

        // robots.txt — parse disallow, sitemap refs
        if (f.key === "robots") {
          const lines      = text.split("\n").map(l => l.trim()).filter(Boolean);
          const disallows  = lines.filter(l => /^Disallow:/i.test(l)).map(l => l.replace(/^Disallow:\s*/i, "")).filter(Boolean);
          const sitemapRef = lines.filter(l => /^Sitemap:/i.test(l)).map(l => l.replace(/^Sitemap:\s*/i, ""));
          const crawlDelay = lines.find(l => /^Crawl-delay:/i.test(l));
          const userAgents = [...new Set(lines.filter(l => /^User-agent:/i.test(l)).map(l => l.replace(/^User-agent:\s*/i, "")))];
          const hasGptBot  = text.toLowerCase().includes("gptbot");
          const hasClaudeBot = text.toLowerCase().includes("claudebot") || text.toLowerCase().includes("claude-web");
          extra = {
            disallowCount: disallows.length,
            disallows:     disallows.slice(0, 10),
            sitemapRefs:   sitemapRef.slice(0, 5),
            crawlDelay:    crawlDelay ? crawlDelay.replace(/^Crawl-delay:\s*/i, "") : null,
            userAgents:    userAgents.slice(0, 8),
            hasGptBot,
            hasClaudeBot,
            lineCount:     lines.length,
          };
        }

        // sitemap.xml — count URLs
        if (f.key === "sitemap" || f.key === "sitemapIndex") {
          const urlCount  = (text.match(/<url>/gi) || []).length;
          const locCount  = (text.match(/<loc>/gi) || []).length;
          const isIndex   = text.includes("<sitemapindex") || text.includes("<sitemap>");
          const lastmod   = text.match(/<lastmod>([^<]+)<\/lastmod>/)?.[1] || null;
          extra = {
            urlCount:  urlCount || locCount,
            isIndex,
            lastmod,
            sizeKb:    Math.round(text.length / 1024 * 10) / 10,
          };
        }

        // llms.txt — preview first few lines
        if (f.key === "llms" || f.key === "llmsFull") {
          const lines = text.split("\n").filter(Boolean).slice(0, 8);
          extra = {
            lineCount: text.split("\n").filter(Boolean).length,
            preview:   lines,
            sizeKb:    Math.round(text.length / 1024 * 10) / 10,
          };
        }
      }

      results[f.key] = {
        label:       f.label,
        url:         f.url,
        status:      res.status,
        ok:          res.ok,
        required:    f.required,
        contentType,
        preview,
        extra,
      };

    } catch (err) {
      results[f.key] = {
        label:    f.label,
        url:      f.url,
        status:   err.name === "AbortError" ? "timeout" : "error",
        ok:       false,
        required: f.required,
        extra:    {},
        error:    err.message,
      };
    }
  }));

  return results;
}
