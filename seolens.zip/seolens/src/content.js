// SEOLens — content.js

(() => {

  const getMeta = (name) =>
    document.querySelector(`meta[name="${name}"]`)?.getAttribute("content") ||
    document.querySelector(`meta[property="${name}"]`)?.getAttribute("content") ||
    null;

  const getCharStatus = (len, min, max) => {
    if (len < min) return "short";
    if (len > max) return "long";
    return "ok";
  };

  // ─── Meta ─────────────────────────────────────────────────────────────────────

  const title     = document.title || null;
  const metaDesc  = getMeta("description");
  const canonical = document.querySelector("link[rel='canonical']")?.href || null;
  const robots    = getMeta("robots");
  const lang      = document.documentElement.lang || null;

  // ─── OG ───────────────────────────────────────────────────────────────────────

  const og = {
    title:       getMeta("og:title"),
    description: getMeta("og:description"),
    image:       getMeta("og:image"),
    type:        getMeta("og:type"),
    url:         getMeta("og:url"),
    siteName:    getMeta("og:site_name"),
  };

  const twitter = {
    card:  getMeta("twitter:card"),
    title: getMeta("twitter:title"),
    image: getMeta("twitter:image"),
  };

  // ─── Headings ─────────────────────────────────────────────────────────────────

  const headings = [];
  ["h1","h2","h3","h4","h5","h6"].forEach(tag => {
    document.querySelectorAll(tag).forEach(el => {
      headings.push({ level: parseInt(tag[1]), text: el.innerText.trim().slice(0, 120) });
    });
  });

  // ─── Schema.org — robust detection ────────────────────────────────────────────
  // Handles: @graph, nested subOrganization/subItems, arrays, Microdata, hatom

  const schemas = [];
  const seenTypes = new Set();

  function extractSchemaTypes(obj, depth) {
    if (!obj || typeof obj !== "object" || depth > 6) return;
    if (Array.isArray(obj)) { obj.forEach(i => extractSchemaTypes(i, depth)); return; }

    if (obj["@type"]) {
      const types = Array.isArray(obj["@type"]) ? obj["@type"] : [obj["@type"]];
      types.forEach(t => {
        if (t && !seenTypes.has(t)) {
          seenTypes.add(t);
          schemas.push({ type: t, raw: obj, source: "json-ld" });
        }
      });
    }
    // Recurse into @graph and common nested keys
    ["@graph", "subOrganization", "hasPart", "itemListElement", "potentialAction",
     "breadcrumb", "publisher", "author", "founder", "creator"].forEach(key => {
      if (obj[key]) extractSchemaTypes(obj[key], depth + 1);
    });
  }

  // JSON-LD
  document.querySelectorAll('script[type="application/ld+json"]').forEach(script => {
    try {
      const raw = script.textContent.trim();
      if (!raw) return;
      const data = JSON.parse(raw);
      const items = Array.isArray(data) ? data : [data];
      items.forEach(item => extractSchemaTypes(item, 0));
    } catch (_) {}
  });

  // Microdata fallback (e.g. hatom, hentry)
  document.querySelectorAll("[itemtype]").forEach(el => {
    const typeUrl = el.getAttribute("itemtype") || "";
    const type = typeUrl.split("/").pop();
    if (type && !seenTypes.has(type)) {
      seenTypes.add(type);
      schemas.push({ type, raw: { "@type": type }, source: "microdata" });
    }
  });

  // ─── Text/HTML ratio ──────────────────────────────────────────────────────────
  // Methodology: strip <script>, <style>, <noscript> tags + HTML comments from outerHTML,
  // then compare visible text length vs clean HTML length — matches SEOquake approach.

  const bodyText = document.body?.innerText || "";

  const textHtmlRatio = (() => {
    try {
      const clone = document.documentElement.cloneNode(true);
      // Remove script, style, noscript, svg content
      clone.querySelectorAll("script, style, noscript, svg").forEach(el => el.remove());
      // Get clean HTML string
      let cleanHtml = clone.outerHTML
        .replace(/<!--[\s\S]*?-->/g, "")   // HTML comments
        .replace(/\s+/g, " ")               // collapse whitespace
        .trim();
      const htmlSize = cleanHtml.length;
      // Visible text: strip all remaining tags
      const textOnly = cleanHtml.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
      const textSize = textOnly.length;
      if (htmlSize === 0) return 0;
      return parseFloat(((textSize / htmlSize) * 100).toFixed(1));
    } catch (_) {
      // fallback to simple method
      const htmlSize = document.documentElement.outerHTML.length;
      const textSize = bodyText.length;
      return htmlSize > 0 ? parseFloat(((textSize / htmlSize) * 100).toFixed(1)) : 0;
    }
  })();

  // ─── Links ────────────────────────────────────────────────────────────────────

  const origin   = window.location.origin;
  const allLinks = Array.from(document.querySelectorAll("a[href]"));
  const links    = allLinks.slice(0, 200).map(a => ({
    href:       a.href,
    text:       a.innerText.trim().slice(0, 80),
    isExternal: !a.href.startsWith(origin),
    isNofollow: (a.rel || "").includes("nofollow"),
  }));

  const internalLinks = links.filter(l => !l.isExternal).length;
  const externalLinks = links.filter(l =>  l.isExternal).length;
  const nofollowLinks = links.filter(l =>  l.isNofollow).length;

  // ─── Images ───────────────────────────────────────────────────────────────────

  const images     = Array.from(document.querySelectorAll("img")).slice(0, 100).map(img => ({
    src:    img.src,
    alt:    img.alt || "",
    width:  img.naturalWidth  || img.width  || null,
    height: img.naturalHeight || img.height || null,
    hasAlt: img.alt.trim().length > 0,
  }));
  const imagesNoAlt = images.filter(i => !i.hasAlt);

  // ─── Keywords ─────────────────────────────────────────────────────────────────

  const words = bodyText
    .toLowerCase()
    .replace(/[^a-záäčďéíľĺňóôŕšťúýžA-ZÁÄČĎÉÍĽĹŇÓÔŔŠŤÚÝŽ\s]/g, " ")
    .split(/\s+/)
    .filter(w => w.length > 3);

  const stopWords = new Set([
    "tento","táto","toto","tieto","ktorý","ktorá","ktoré","ktorí",
    "jeho","jej","ich","seba","mňa","teba","nás","vás",
    "alebo","avšak","pretože","lebo","keďže","hoci","pokiaľ","zatiaľ",
    "from","that","this","with","have","will","your","more","also",
    "about","there","their","which","would","could","should",
    "veľmi","všetky","všetci","každý","každá","každé","celý","celá",
  ]);

  const freq = {};
  words.forEach(w => { if (!stopWords.has(w)) freq[w] = (freq[w] || 0) + 1; });

  const totalWords  = words.length;
  const topKeywords = Object.entries(freq)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 30)
    .map(([word, count]) => ({
      word, count,
      density: parseFloat(((count / totalWords) * 100).toFixed(2)),
    }));

  // ─── Core Web Vitals ──────────────────────────────────────────────────────────
  // Primárny zdroj: sessionStorage uložený cwv-collector.js (beží od document_start)
  // Fallback: PerformanceObserver buffered (funguje pre FCP, TTFB, CLS ale nie LCP/FID)

  const cwv = { lcp: null, cls: null, fid: null, fcp: null, ttfb: null };

  // Načítaj z sessionStorage (uložil cwv-collector.js)
  try {
    const stored = sessionStorage.getItem("__seolens_cwv__");
    if (stored) {
      const parsed = JSON.parse(stored);
      if (parsed.lcp  !== null && parsed.lcp  !== undefined) cwv.lcp  = parsed.lcp;
      if (parsed.cls  !== null && parsed.cls  !== undefined) cwv.cls  = parsed.cls;
      if (parsed.fid  !== null && parsed.fid  !== undefined) cwv.fid  = parsed.fid;
      if (parsed.fcp  !== null && parsed.fcp  !== undefined) cwv.fcp  = parsed.fcp;
      if (parsed.ttfb !== null && parsed.ttfb !== undefined) cwv.ttfb = parsed.ttfb;
    }
  } catch (_) {}

  // Fallback — dopln čo chýba z Performance API
  if (cwv.ttfb === null || cwv.fcp === null) {
    try {
      const nav = performance.getEntriesByType("navigation")[0];
      if (nav && cwv.ttfb === null) cwv.ttfb = Math.round(nav.responseStart - nav.requestStart);
      const fcp = performance.getEntriesByType("paint").find(e => e.name === "first-contentful-paint");
      if (fcp && cwv.fcp === null) cwv.fcp = Math.round(fcp.startTime);
    } catch (_) {}
  }

  if (cwv.lcp === null) {
    try {
      const list = [];
      const o = new PerformanceObserver(l => l.getEntries().forEach(e => list.push(e)));
      o.observe({ type: "largest-contentful-paint", buffered: true });
      o.disconnect();
      if (list.length) cwv.lcp = Math.round(list[list.length - 1].startTime);
    } catch (_) {}
  }

  if (cwv.cls === null) {
    try {
      let val = 0;
      const o = new PerformanceObserver(l => l.getEntries().forEach(e => { if (!e.hadRecentInput) val += e.value; }));
      o.observe({ type: "layout-shift", buffered: true });
      o.disconnect();
      cwv.cls = parseFloat(val.toFixed(4));
    } catch (_) {}
  }

  if (cwv.fid === null) {
    try {
      const list = [];
      const o = new PerformanceObserver(l => l.getEntries().forEach(e => list.push(e)));
      o.observe({ type: "first-input", buffered: true });
      o.disconnect();
      if (list.length) cwv.fid = Math.round(list[0].processingStart - list[0].startTime);
    } catch (_) {}
  }

  const cwvStatus = {
    lcp:  cwv.lcp  === null ? "unknown" : cwv.lcp  <= 2500 ? "ok" : cwv.lcp  <= 4000 ? "warn" : "err",
    cls:  cwv.cls  === null ? "unknown" : cwv.cls  <= 0.1  ? "ok" : cwv.cls  <= 0.25  ? "warn" : "err",
    fid:  cwv.fid  === null ? "unknown" : cwv.fid  <= 100  ? "ok" : cwv.fid  <= 300   ? "warn" : "err",
    fcp:  cwv.fcp  === null ? "unknown" : cwv.fcp  <= 1800 ? "ok" : cwv.fcp  <= 3000  ? "warn" : "err",
    ttfb: cwv.ttfb === null ? "unknown" : cwv.ttfb <= 800  ? "ok" : cwv.ttfb <= 1800  ? "warn" : "err",
  };

  // ─── Hreflang ─────────────────────────────────────────────────────────────────

  const hreflang = Array.from(document.querySelectorAll("link[hreflang]")).map(el => ({
    lang: el.hreflang, href: el.href,
  }));

  // ─── Misc ─────────────────────────────────────────────────────────────────────

  const isHttps       = location.protocol === "https:";
  const hasSitemap    = !!document.querySelector("link[rel='sitemap']");
  const hasViewport   = !!getMeta("viewport");
  const isThinContent = totalWords < 300;

  return {
    url:       window.location.href,
    timestamp: new Date().toISOString(),

    meta: {
      title,
      titleLength: title?.length || 0,
      titleStatus: getCharStatus(title?.length || 0, 30, 60),
      description: metaDesc,
      descLength:  metaDesc?.length || 0,
      descStatus:  getCharStatus(metaDesc?.length || 0, 120, 160),
      canonical, robots, lang,
    },

    og, twitter, headings,

    schema: { items: schemas, types: schemas.map(s => s.type) },

    links: {
      total: links.length, internal: internalLinks,
      external: externalLinks, nofollow: nofollowLinks,
      list: links.slice(0, 50),
    },

    images: {
      total:     images.length,
      noAltCount: imagesNoAlt.length,
      noAltList:  imagesNoAlt.slice(0, 20),
      list:       images.slice(0, 30),
    },

    keywords: { totalWords, top: topKeywords },
    textHtmlRatio,
    cwv, cwvStatus, hreflang,

    misc: { isHttps, hasSitemap, hasViewport, isThinContent },
  };

})();
