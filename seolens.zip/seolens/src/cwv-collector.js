// SEOLens — cwv-collector.js
// Injected at document_start — registruje observers čo najskôr
// aby zachytil LCP, CLS, FID od začiatku načítavania.
// Výsledky ukladá do sessionStorage, content.js ich potom prečíta.

(function() {
  var store = { lcp: null, cls: 0, fid: null, fcp: null, ttfb: null };

  // LCP — musí byť registrovaný čo najskôr
  try {
    var lcpObs = new PerformanceObserver(function(list) {
      var entries = list.getEntries();
      if (entries.length) store.lcp = Math.round(entries[entries.length - 1].startTime);
    });
    lcpObs.observe({ type: "largest-contentful-paint", buffered: true });
  } catch(_) {}

  // CLS
  try {
    var clsObs = new PerformanceObserver(function(list) {
      list.getEntries().forEach(function(e) {
        if (!e.hadRecentInput) store.cls = parseFloat((store.cls + e.value).toFixed(4));
      });
    });
    clsObs.observe({ type: "layout-shift", buffered: true });
  } catch(_) {}

  // FID
  try {
    var fidObs = new PerformanceObserver(function(list) {
      var e = list.getEntries()[0];
      if (e && store.fid === null) store.fid = Math.round(e.processingStart - e.startTime);
    });
    fidObs.observe({ type: "first-input", buffered: true });
  } catch(_) {}

  // FCP + TTFB — čítame z bufferu keď je stránka hotová
  function collectPaintAndNav() {
    try {
      var nav = performance.getEntriesByType("navigation")[0];
      if (nav) store.ttfb = Math.round(nav.responseStart - nav.requestStart);
    } catch(_) {}
    try {
      var paints = performance.getEntriesByType("paint");
      var fcp = paints && paints.find(function(e) { return e.name === "first-contentful-paint"; });
      if (fcp) store.fcp = Math.round(fcp.startTime);
    } catch(_) {}
  }

  // Uložíme do sessionStorage keď je stránka načítaná
  function save() {
    collectPaintAndNav();
    try {
      sessionStorage.setItem("__seolens_cwv__", JSON.stringify(store));
    } catch(_) {}
  }

  if (document.readyState === "complete") {
    save();
  } else {
    window.addEventListener("load", function() {
      // Malý delay aby LCP observer stihol finálny záznam
      setTimeout(save, 300);
    });
  }

  // Aj pri viditeľnosti (keď sa vrátim na tab)
  document.addEventListener("visibilitychange", function() {
    if (document.visibilityState === "visible") save();
  });
})();
